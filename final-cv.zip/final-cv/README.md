# final cv

A Pen created on CodePen.io. Original URL: [https://codepen.io/Goparaju-Sree-vatsava/pen/wvOoRQK](https://codepen.io/Goparaju-Sree-vatsava/pen/wvOoRQK).

